(function () {
  // [pattern, label, kg CO2e (rough category average), used/refurb factor, word]
  var CATS = [
    [/\b(laptop|notebook|macbook|chromebook)s?\b/i, "laptop", 300, 0.3, "refurbished"],
    [/\b(monitor)s?\b/i, "monitor", 250, 0.35, "refurbished"],
    [/\b(tv|television)s?\b/i, "TV", 400, 0.35, "refurbished"],
    [/\b(camera)s?\b/i, "camera", 200, 0.3, "used"],
    [/\b(tablet|ipad)s?\b/i, "tablet", 120, 0.3, "refurbished"],
    [/\b(smartphone|iphone|galaxy|pixel|cell phone|phone)s?\b/i, "phone", 70, 0.25, "refurbished"],
    [/\b(mattress)\b/i, "mattress", 100, 0.5, "used"],
    [/\b(smartwatch|apple watch|fitbit)\b/i, "smartwatch", 40, 0.3, "refurbished"],
    [/\b(vacuum)s?\b/i, "vacuum", 40, 0.4, "refurbished"],
    [/\b(headphones?|earbuds?|airpods)\b/i, "headphones", 25, 0.35, "refurbished"],
    [/\b(chair|desk|sofa|couch)s?\b/i, "furniture", 60, 0.2, "used"],
    [/\b(jeans|denim)\b/i, "jeans", 33, 0.15, "secondhand"],
    [/\b(jacket|coat|hoodie)s?\b/i, "jacket", 25, 0.15, "secondhand"],
    [/\b(sneakers?|shoes?|boots?)\b/i, "shoes", 14, 0.2, "secondhand"],
    [/\b(backpack)s?\b/i, "backpack", 15, 0.2, "secondhand"],
    [/\b(keyboard)s?\b/i, "keyboard", 15, 0.4, "used"],
    [/\b(t-?shirt|tee)s?\b/i, "t-shirt", 7, 0.15, "secondhand"],
    [/\b(toy|lego)s?\b/i, "toy", 10, 0.2, "used"],
    [/\b(book|paperback|hardcover)s?\b/i, "book", 2.5, 0.1, "used"]
  ];
  var SEARCH = {
    "amazon.com": "/s?k=", "ebay.com": "/sch/i.html?_nkw=", "walmart.com": "/search?q=",
    "bestbuy.com": "/site/searchpage.jsp?st=", "target.com": "/s?searchTerm="
  };
  var PRODUCT_URL = /(\/dp\/|\/gp\/product\/|\/ip\/|\/itm\/|\/p\/|\.p\b|\/A-\d+)/;
  var last = "";
  var dismissedKey = "";
  var currentCat = null;

  function fmt(n) { return n >= 10 ? Math.round(n) : n.toFixed(1); }

  function findCat(title) {
    for (var i = 0; i < CATS.length; i++) if (CATS[i][0].test(title)) return CATS[i];
    return null;
  }

  function build(cat, searchUrl) {
    var kg = cat[2], alt = kg * cat[3], saved = kg - alt;
    var tier = kg < 10 ? ["#1F6B4A", "#D3EBDD"] : kg < 50 ? ["#8A5A00", "#FBEFD0"] : ["#B4540A", "#FBE6D0"];
    var host = document.createElement("div");
    host.id = "greenprint-badge";
    var root = host.attachShadow({ mode: "open" });
    var style = document.createElement("style");
    style.textContent =
      ".b{font:14px/1.45 system-ui,sans-serif;margin:10px 0;padding:10px 12px;border-radius:8px;" +
      "border:1px solid " + tier[0] + ";background:" + tier[1] + ";color:#13201A;max-width:520px}" +
      ".h{display:flex;justify-content:space-between;gap:8px;align-items:center;font-weight:700}" +
      ".h span{color:" + tier[0] + "}" +
      ".x{all:unset;cursor:pointer;padding:0 4px;font-size:16px}" +
      ".x:focus-visible,a:focus-visible{outline:2px solid #13201A;outline-offset:2px}" +
      "p{margin:4px 0 0}small{color:#4a5a51}a{color:#13201A;font-weight:600}";
    var box = document.createElement("div");
    box.className = "b";
    box.setAttribute("role", "note");
    var head = document.createElement("div");
    head.className = "h";
    var t = document.createElement("span");
    t.textContent = "Greenprint: about " + fmt(kg) + " kg CO\u2082e";
    var x = document.createElement("button");
    x.className = "x"; x.textContent = "\u00d7"; x.setAttribute("aria-label", "Dismiss Greenprint");
    x.onclick = function () { dismissedKey = last; host.remove(); };
    head.appendChild(t); head.appendChild(x);
    var p = document.createElement("p");
    p.textContent = "Buying " + cat[4] + " instead could cut this to about " + fmt(alt) +
      " kg, saving " + fmt(saved) + " kg (like not driving " + Math.round(saved / 0.25) + " km). ";
    if (searchUrl) {
      var a = document.createElement("a");
      a.href = searchUrl; a.textContent = "See " + cat[4] + " " + cat[1] + "s";
      p.appendChild(a);
    }
    var s = document.createElement("p");
    var sm = document.createElement("small");
    sm.textContent = "Rough " + cat[1] + " category estimate, not measured for this exact product.";
    s.appendChild(sm);
    box.appendChild(head); box.appendChild(p); box.appendChild(s);
    root.appendChild(style); root.appendChild(box);
    return host;
  }

  function removeBadge() {
    var old = document.getElementById("greenprint-badge");
    if (old) old.remove();
  }

  function run() {
    try {
      if (!PRODUCT_URL.test(location.href)) { removeBadge(); last = ""; currentCat = null; return; }
      var h = document.querySelector("#productTitle, h1[itemprop='name'], h1");
      if (!h) return;
      var title = (h.textContent || "").trim();
      if (!title) return;
      var key = location.href + "|" + title;
      if (key !== last) {
        last = key;
        currentCat = findCat(title);
        removeBadge();
      }
      // Re-insert if the site re-rendered and removed our badge (unless dismissed)
      if (!currentCat || key === dismissedKey || document.getElementById("greenprint-badge")) return;
      var base = null;
      for (var d in SEARCH) if (location.hostname.endsWith(d)) base = d;
      var url = base ? location.origin + SEARCH[base] + encodeURIComponent(currentCat[4] + " " + currentCat[1]) : null;
      var anchor = h.closest("#titleSection, #title_feature_div") || h.closest("h1") || h;
      anchor.insertAdjacentElement("afterend", build(currentCat, url));
    } catch (e) { /* never break the host page */ }
  }

  run();
  setInterval(run, 1000); // handles re-renders and in-page navigation
})();
